const CACHE = "orbis-doctrina-v1";
const ASSETS = [
  "./", "./index.html", "./d3.min.js", "./manifest.webmanifest",
  "./icons/icon-192.png", "./icons/icon-512.png",
  "./icons/icon-maskable-512.png", "./icons/apple-touch-icon-180.png"
];

self.addEventListener("install", (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    await Promise.allSettled(ASSETS.map((u) => c.add(u)));
    self.skipWaiting();
  })());
});

self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;

  // navigations: network first, fall back to cached shell (offline)
  if (req.mode === "navigate") {
    e.respondWith((async () => {
      try { return await fetch(req); }
      catch (_) {
        const c = await caches.open(CACHE);
        return (await c.match("./index.html")) || Response.error();
      }
    })());
    return;
  }

  // everything else: cache first, then network (and cache the result, incl. CDN d3)
  e.respondWith((async () => {
    const c = await caches.open(CACHE);
    const hit = await c.match(req);
    if (hit) return hit;
    try {
      const res = await fetch(req);
      if (res && (res.ok || res.type === "opaque")) { c.put(req, res.clone()).catch(() => {}); }
      return res;
    } catch (_) {
      return hit || Response.error();
    }
  })());
});
