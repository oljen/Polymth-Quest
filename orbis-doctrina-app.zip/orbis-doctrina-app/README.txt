ORBIS DOCTRINA - installable web app (PWA)
==========================================

Files
  index.html            the app
  d3.min.js             globe rendering library (works offline)
  manifest.webmanifest  app name, icons, colours
  sw.js                 service worker (offline support)
  icons/                app icons

How to put it on your devices
-----------------------------
A PWA must be served over HTTPS. Easiest free options (no build step):

  - Netlify Drop: go to https://app.netlify.com/drop and drag this whole
    folder onto the page. You get a public https URL in seconds.
  - Cloudflare Pages or Vercel: create a project and upload this folder.
  - GitHub Pages: push these files to a repo and enable Pages.

Then open that URL on each device and install:

  iPhone / iPad (Safari):  Share button  ->  Add to Home Screen
  Mac (Safari):            File  ->  Add to Dock
  Mac/Windows (Chrome):    install icon in the address bar

It launches full-screen with its own icon, works offline after the first
load, and remembers discoveries on that device.

Test locally first (optional)
------------------------------
  cd orbis-doctrina-app
  python3 -m http.server 8000
  open http://localhost:8000   (localhost counts as secure, so install works)

Note on sharing between people
------------------------------
Right now each device keeps its own discoveries (stored locally). Making
posts appear on everyone's Earth in real time is the next step: a small
backend (e.g. Supabase) the app reads from and writes to.
